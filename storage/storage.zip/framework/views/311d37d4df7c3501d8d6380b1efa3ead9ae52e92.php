  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Pengadaan</b> App
    </div>
    <strong>Copyright &copy; <?php echo e(date('d-M-Y')); ?> <a href="">Pengadaan</a>.</strong> All rights reserved.
  </footer>

  <?php echo $__env->make('suplier.ubahpassword', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('admin.ubahpassword', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\bkpsdm\pengadaan\resources\views/parsial/footer.blade.php ENDPATH**/ ?>
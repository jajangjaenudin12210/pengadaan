    <ul class="navbar-nav ml-auto">
     
      <!-- Notifications Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="fas fa-users-cog"></i>

        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <div class="dropdown-divider"></div>
         <button type="button" class="dropdown-item" data-toggle="modal" data-target="#ubahPasswordAdm"><i class="fas fa-key mr-2"></i>Password</button>
          <div class="dropdown-divider"></div>
          <a href="/keluarAdmin" class="dropdown-item">
            <i class="fas fa-sign-out-alt mr-2"></i> Keluar
          </a>
          <div class="dropdown-divider"></div>
          <div class="dropdown-divider"></div>
        </div>
      </li>
    </ul>
<?php /**PATH C:\xampp\htdocs\bkpsdm\pengadaan\resources\views/parsial/setting.blade.php ENDPATH**/ ?>
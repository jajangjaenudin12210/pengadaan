  <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item">
            <a href="/" class="nav-link">
              <i class="nav-icon fas fa-home"></i>
              <p>
                Halaman Depan
                <span class="right badge badge-danger"></span>
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="/listSuplier" class="nav-link">
              <i class="nav-icon fas fa-list"></i>
              <p>
                Pengajuan
                <span class="right badge badge-danger"></span>
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="/riwayatku" class="nav-link">
              <i class="nav-icon fa fa-history"></i>
              <p>
                Riwayat
                <span class="right badge badge-danger"></span>
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="/pengajuanselesai" class="nav-link">
              <i class="nav-icon fa fa-history"></i>
              <p>
                Pengajuan Selesai
                <span class="right badge badge-danger"></span>
              </p>
            </a>
          </li>

        </ul>
      </nav>
    <?php /**PATH C:\xampp\htdocs\bkpsdm\pengadaan\resources\views/suplier/menu.blade.php ENDPATH**/ ?>